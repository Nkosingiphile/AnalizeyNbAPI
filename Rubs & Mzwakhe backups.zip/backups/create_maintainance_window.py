import requests
import json
import time
import datetime
from datetime import date
import sys
from datetime import timezone

today = date.today()

address = 'http://10.132.98.168/api/v2/'
creds = {'name': 'MzwakheB', 'password':'v0dac0m'}
r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
response = json.loads( r.text )

today_date = datetime.date.today()
start_date = datetime.datetime(today_date.year, today_date.month, today_date.day, 20, 00).timestamp()

tomorrow_date = datetime.date.today() + datetime.timedelta(days=1)
end_date = datetime.datetime(tomorrow_date.year, tomorrow_date.month, tomorrow_date.day, 3, 00).timestamp()


print(int(start_date) * 1000)
print(int(end_date) * 1000)

data = {
    "actions": [
        "CATEGORIZE_ALERTS",
        "EXCLUDE_DATA_FROM_BASELINES",
        "SUPPRESS_ALERT_NOTIFICATIONS",
        "EXCLUDE_DATA_FROM_AGGREGATION"
    ],
    "deviceIds": [
        33,
        34,
        35,
        36,
        4,
        37,
        5,
        38,
        6,
        39,
        11,
        14,
        15,
        16,
        20,
        22,
        23,
        24,
        25,
        26,
        28,
        29,
        30,
        31
    ],
    "maintenanceType": "PLANNED",
    "name": "%s_maintaince" % (today.strftime("%B %d, %Y")),
    "notes": "According to Wayne",
    "scheduleInstance": {
      "beginDateTime": "%s" % (int(start_date) * 1000), 
      "endDateTime": "%s" % (int(end_date) * 1000)
    }
}

session = requests.Session()
session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})

response = session.post(address + "/maintenancewindows",
                   data=json.dumps(data),
                   headers = { 'content-type': 'application/json' })

print(response.content)
print(response.status_code)
