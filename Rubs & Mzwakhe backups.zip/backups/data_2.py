import requests
import json
import time
import datetime
from datetime import date
import sys
from datetime import timezone
import mysql.connector as mysql
import xlsxwriter
import os

def readable_date(timestamp):
    readable_time = datetime.datetime.fromtimestamp(int(timestamp)/1000).strftime('%Y-%m-%d %H:%M:%S')
    return readable_time

def filename_date(timestamp):
    filename_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime('%Y_%m_%d__%H-%M-%S')
    return filename_date

start = time.time()
yesterday_date = datetime.date.today() + datetime.timedelta(days=-4)

days_date = []

for i in range(1,8):
    days_date.append(datetime.date.today() + datetime.timedelta(days=-i))
print(days_date)

startTime = datetime.datetime(yesterday_date.year, yesterday_date.month, yesterday_date.day, 5, 00).timestamp()
endTime = datetime.datetime(yesterday_date.year, yesterday_date.month, yesterday_date.day, 22, 00).timestamp()


reportName='Vodacom_Aggregation_Report_' + filename_date(time.time())
workbook = xlsxwriter.Workbook(reportName + ".xlsx")
worksheet = workbook.add_worksheet()
number = workbook.add_format({'num_format': '0.00'})
high_pres = workbook.add_format({'num_format': '#.#####'})
xr=1
xc=1
worksheet.write('{}{}'.format('A',xr),'Region')
worksheet.write('{}{}'.format('B',xr),'Session Name')
worksheet.write('{}{}'.format('C',xr),'Atol ID')
worksheet.write('{}{}'.format('D',xr),'5-minutes (Yesterday)')
worksheet.write('{}{}'.format('E',xr),'1-minute  (Yesterday)')

db = mysql.connect(
    host = "10.13.56.190",
    user = "willcom",
    password = "w1llc0m",
    database = "SevOne_info"
    )

# Log into SevOne API.
address = 'http://10.132.98.168/api/v2/'
creds = {'name': 'MzwakheB', 'password':'v0dac0m'}
r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
response = json.loads( r.text )

# Open a session for credential handling.
session = requests.Session()
session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})
	
cursor = db.cursor()

query = '''SELECT Device_ID, Object_ID, Indicactor_ID, Device_Name, Object_Name, Obj_desc FROM SevOne_Object''' 
cursor.execute(query)
records = cursor.fetchall()

xr+=1
for record in records:
    device_id = record[0]
    object_id = record[1]
    indicator_id = record[2]
    region = record[3]
    session_name = record[4]
    atol_id = record[5]
	
    data_site = session_name.split('(')
    site_name = data_site[0]
    #print(site_name)
	
    indicatorDataUrl = address + "devices/{}/objects/{}/indicators/{}/data".format(device_id,object_id, indicator_id)
    params = { 'startTime': int(startTime) * 1000, 'endTime': int(endTime) * 1000 }
    r = session.get( indicatorDataUrl, params=params )
    response = json.loads(r.text)
    #print(json.dumps(response, indent=4, sort_keys=True))
    object_total = 0
    try:
        
        for x in range(0,len(response),5):
            #print(response[x]['time'])
            object_total += response[x]['value']
        object_avg = object_total/(len(response)/5)
        for y in response:
            object_total += y['value']
        minute_avg = object_total/(len(response))
        if object_avg > 100:
           object_avg = 100.0000
        if minute_avg > 100:
           minute_avg = 100.0000
        row_data=[region, session_name, atol_id, '%.4f' % object_avg,  '%.4f' % minute_avg]
        print(row_data)
        worksheet.write_row('{}{}'.format('A',xr),row_data,number)
        xr+=1
        worksheet.set_column('C:E',15,high_pres)
        worksheet.set_column(1,1,50)
    except:
        -99
workbook.close()
print(reportName)
print(yesterday_date)
end = time.time()
time_range = end - start
print(time_range)