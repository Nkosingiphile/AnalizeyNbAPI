import sys
import pexpect
import time
import os

VCX_IPS = [
    '10.132.98.169'
]

VCX_USR = [
    'admin'
]

VCX_PASS = [
    'admin'
]

NANO = [
    'Proxy-9059',
    'LAB_Pcap-8023'
]

def connect_to_vcx():
    child = pexpect.spawn('ssh -o "StrictHostKey no" %s@%s' % ('admin', '10.132.98.169'))
    time.sleep(1)
    child.timeout = 120
    print('script loggin in....')
    child.expect('password:')
    child.sendline('admin')
    print('script logged in....')
    child.expect(':')
    child.sendline('session writelock')
    child.expect(':')
    child.sendline('remote device show %s' % (NANO[0]))
    child.expect(':')
    results = child.before
    print(type(results))
    print(results)

connect_to_vcx()
