import requests
import json
import time
import datetime
import sys
import xlsxwriter
from operator import itemgetter
#import smtplib
#import os.path
#from email.MIMEMultipart import MIMEMultipart
#from email.mime.application import MIMEApplication
#from email.MIMEBase import MIMEBase
#from email.MIMEText import MIMEText
import os
import datetime
import random

#def send_email(subject, message, from_email, to_email=[], attachment=[]):
#    """
#    :param subject: email subject
#    :param message: Body content of the email (string), can be HTML/CSS or plain text
#    :param from_email: Email address from where the email is sent
#    :param to_email: List of email recipients, example: ["a@a.com", "b@b.com"]
#    :param attachment: List of attachments, exmaple: ["file1.txt", "file2.txt"]
#    """
#    msg = MIMEMultipart()
#    msg['Subject'] = subject
#    msg['From'] = from_email
#    msg['To'] = ", ".join(to_email)
#    msg.attach(MIMEText(message, 'html'))

#    for f in attachment:
#        with open(f, 'rb') as a_file:
#            basename = os.path.basename(f)
#            part = MIMEApplication(a_file.read(), Name=basename)

#        part['Content-Disposition'] = 'attachment; filename="%s"' % basename
#        msg.attach(part)

#    email = smtplib.SMTP('10.74.25.17')
#    email.sendmail(from_email, to_email, msg.as_string())

def readable_date(timestamp):
    readable_time = datetime.datetime.fromtimestamp(int(timestamp)/1000).strftime('%Y-%m-%d %H:%M:%S')
    return readable_time

def filename_date(timestamp):
    filename_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime('%Y_%m_%d__%H-%M-%S')
    return filename_date
if __name__ == "__main__":
    print (datetime.datetime.now())
    address = 'http://10.132.98.168/api/v2/'
    creds = {'name': 'GiftM', 'password':'v0dac0m'}
    r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
    response = json.loads( r.text )

# Open a session for credential handling.
    session = requests.Session()
    session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})
 

    reports={'BE': {'DL': '1503', 'PL': '1504'}, 'EF': {'DL': '1645', 'PL': '1646'}}
    data={}
    for report_key in reports.keys():
        dl_id=reports[report_key]['DL']
        pl_id=reports[report_key]['PL']

        data[report_key]={}
        r = session.get(address + 'reports/attachments/topn/{}/run'.format(dl_id))
        data[report_key]['DL'] = json.loads(r.text)['result']
        r = session.get(address + 'reports/attachments/topn/{}/run'.format(pl_id))
        data[report_key]['PL'] = json.loads(r.text)['result']
    #print (data.keys())
    #print (data['BE'].keys(),data['EF'].keys())
    #print (len(data['BE']['DL']),len(data['BE']['PL']),len(data['EF']['DL']),len(data['EF']['PL']))

    #create Kavash's report
    regions = ['CEN','EAS','KZN','LIM','MPU','NGA','SGC','SGS','WES']
    r_be_Ogroups = {'CEN':0,'EAS':0,'KZN':0,'LIM':0,'MPU':0,'NGA':0,'SGC':0,'SGS':0,'WES':0, 'Total':0}
    r_ef_Ogroups = {'CEN':0,'EAS':0,'KZN':0,'LIM':0,'MPU':0,'NGA':0,'SGC':0,'SGS':0,'WES':0, 'Total':0}
    OGroups_BE = [{'name': 'WES_All', 'id': 25}, {'name': 'NGA_All', 'id': 43}, 
               {'name': 'LIM_All', 'id': 45}, {'name': 'CEN_All', 'id': 56}, 
               {'name': 'KZN_All', 'id':57}, {'name': 'SGC_All', 'id': 58}, 
               {'name': 'SGS_All', 'id': 59}, {'name': 'EAS_All', 'id': 67}, 
               {'name': 'MPU_All', 'id': 279}, {'name': 'ALL_BE','id': 273}]
    OGroups_EF = [{'name': 'KZN_EF','id': 292}, {'name': 'ALL_EF', 'id': 272}, 
               {'name': 'SGC_EF', 'id': 293}, {'name': 'NGA_EF', 'id': 295}, 
               {'name': 'SGS_EF', 'id': 296}, {'name': 'WES_EF', 'id': 297}, 
               {'name': 'MPU_EF', 'id': 298}, {'name': 'LIM_EF', 'id': 299}, 
               {'name': 'CEN_EF', 'id': 300}, {'name': 'EAS_EF', 'id': 301}]
    
    total = 0
    for region in OGroups_BE:
        r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(region['id']))
        objects = json.loads(r.text)
        count = len(objects['members'])
        for item in r_be_Ogroups:
            if item in region['name']:
                r_be_Ogroups[item]=count
                total=total+count
                break
        
    r_be_Ogroups['Total']=total
    print total
    total = 0
    for region in OGroups_EF:
        r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(region['id']))
        objects = json.loads(r.text)
        count = len(objects['members'])
        for item in r_ef_Ogroups:
            if item in region['name']:
                r_ef_Ogroups[item]=count
                total=total+count
                break

    r_ef_Ogroups['Total']=total
    print total

    be_dl={}
    be_pl={}
    for line_dl,line_pl in zip(data['BE']['DL'],data['BE']['PL']):
        #print line_pl['objectName'],line_dl['objectName']
        for region in regions:
            if not region in be_dl.keys():
                be_dl[region]={'data':[]}
            if "_"+region+"_" in line_dl['objectName']:
                be_dl[region]['data'].append(line_dl)
            if not region in be_pl.keys():
                be_pl[region]={'data':[]}
            if "_"+region+"_" in line_pl['objectName']: 
                be_pl[region]['data'].append(line_pl)
    for region in be_dl.keys():
        print (region,len(be_dl[region]['data']),len(be_pl[region]['data']))

    ef_dl={}
    ef_pl={}
    for line_dl,line_pl in zip(data['EF']['DL'],data['EF']['PL']):
        #print line_pl['objectName'],line_dl['objectName']
        for region in regions:
            if not region in ef_dl.keys():
                ef_dl[region]={'data':[]}
            if "_"+region+"_" in line_dl['objectName']:
                ef_dl[region]['data'].append(line_dl)
            if not region in ef_pl.keys():
                ef_pl[region]={'data':[]}
            if "_"+region+"_" in line_pl['objectName']: 
                ef_pl[region]['data'].append(line_pl)

    ef_delay_threshold = 20000 # value in microseconds
    ef_packetloss_threshold = 0.001 # value in percentage
    be_delay_threshold = 20000 # value in microseconds
    be_packetloss_threshold = 0.5 # value in percentage

    ef_data = {}
    for region in ef_dl.keys():
        if 'Total' not in ef_data.keys():
            ef_data['Total']={'pl_less_threshold':0, 'dl_less_threshold':0,'reflecting':0}
        if not region in ef_data.keys():
            ef_data[region]={'pl_less_threshold':0, 'dl_less_threshold':0,'pl_threshold':ef_packetloss_threshold,'dl_threshold':ef_delay_threshold, 'reflecting':0}
        for session_pl,session_dl in zip(ef_pl[region]['data'],ef_dl[region]['data']):
            if int(session_pl['data'][0]['value'])<=ef_packetloss_threshold:
                ef_data[region]['pl_less_threshold']+=1
                ef_data['Total']['pl_less_threshold']+=1
            if int(session_dl['data'][0]['value'])<ef_delay_threshold:
                ef_data[region]['dl_less_threshold']+=1
                ef_data['Total']['dl_less_threshold']+=1
            ef_data[region]['reflecting']+=1
            ef_data['Total']['reflecting']+=1
    #print (ef_data)
    
    be_data = {}
    for region in be_dl.keys():
        if 'Total' not in be_data.keys():
            be_data['Total']={'pl_less_threshold':0, 'dl_less_threshold':0,'reflecting':0}
        if not region in be_data.keys():
            be_data[region]={'pl_less_threshold':0, 'dl_less_threshold':0,'pl_threshold':be_packetloss_threshold,'dl_threshold':be_delay_threshold, 'reflecting':0}
        for session_pl,session_dl in zip(be_pl[region]['data'],be_dl[region]['data']):
            #print(session_pl['data'][0]['value'])
            if int(session_pl['data'][0]['value'])<=be_packetloss_threshold:
                be_data[region]['pl_less_threshold']+=1
                be_data['Total']['pl_less_threshold']+=1
            if int(session_dl['data'][0]['value'])<be_delay_threshold:
                be_data[region]['dl_less_threshold']+=1
                be_data['Total']['dl_less_threshold']+=1
            be_data[region]['reflecting']+=1
            be_data['Total']['reflecting']+=1

    reportName='Vodacom_Kavash_' + filename_date(time.time())
    workbook = xlsxwriter.Workbook(reportName + ".xlsx")
    worksheet = workbook.add_worksheet()
    percentage = workbook.add_format({'num_format': '0.00%'})
    merge_format = workbook.add_format({
    'bold': 1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'fg_color': 'yellow'})
    heading_format = workbook.add_format({
    'bold': 1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'fg_color': 'white'})

    worksheet.merge_range('A1:H1','EF',merge_format)
    xr=3
    xc=1
    worksheet.write('{}{}'.format('A',xr),'Region',heading_format)
    worksheet.write('{}{}'.format('B',xr),'Total Sessions',heading_format)
    worksheet.write('{}{}'.format('C',xr),'Not Reflecing', heading_format)
    worksheet.write('{}{}'.format('D',xr),'Reflecting',heading_format)
    worksheet.merge_range('E{}:F{}'.format(xr-1,xr-1), 'Delay < {}ms'.format(str(ef_delay_threshold/1000)), merge_format)
    worksheet.write('{}{}'.format('E',xr),'In Spec %', heading_format)
    worksheet.write('{}{}'.format('F',xr),'Out of Spec %', heading_format)
    worksheet.merge_range('G{}:H{}'.format(xr-1,xr-1), 'Packetloss < {}%'.format(str(ef_packetloss_threshold)), merge_format)
    worksheet.write('{}{}'.format('G',xr),'In Spec %', heading_format)
    worksheet.write('{}{}'.format('H',xr),'Out of Spec %', heading_format)
    xr += 1
    regions.append('Total')
    for region in regions: #ef_data.keys():
        worksheet.write('{}{}'.format('A',xr),region, heading_format)
        worksheet.write('{}{}'.format('B',xr),max(r_ef_Ogroups[region],ef_data[region]['reflecting']))
        worksheet.write('{}{}'.format('D',xr),ef_data[region]['reflecting'])
        worksheet.write('{}{}'.format('C',xr),float(max(r_ef_Ogroups[region],ef_data[region]['reflecting']))-float(ef_data[region]['reflecting']))
        delay_in_spec = float(float(ef_data[region]['dl_less_threshold'])/ef_data[region]['reflecting'])
        packetloss_in_spec = float(float(ef_data[region]['pl_less_threshold'])/ef_data[region]['reflecting'])
        #print packetloss_in_spec
        worksheet.write('{}{}'.format('E',xr),delay_in_spec, percentage)
        worksheet.write('{}{}'.format('F',xr),float(1.00)-delay_in_spec,percentage)
        worksheet.write('{}{}'.format('G',xr),packetloss_in_spec,percentage)
        worksheet.write('{}{}'.format('H',xr),float(1.00)-packetloss_in_spec,percentage)
        xr += 1
        if region=='Total':
            worksheet.set_row(xr-2,xr-2,heading_format)
    xr=xr+5
    worksheet.merge_range('A{}:H{}'.format(xr-2,xr-2),'BE',merge_format)
    xc=1
    worksheet.write('{}{}'.format('A',xr),'Region', heading_format)
    worksheet.write('{}{}'.format('B',xr),'Total', heading_format)
    worksheet.write('{}{}'.format('C',xr),'Not Reflecing', heading_format)
    worksheet.write('{}{}'.format('D',xr),'Reflecting', heading_format)
    worksheet.merge_range('E{}:F{}'.format(xr-1,xr-1), 'Delay < {}ms'.format(str(be_delay_threshold/1000)), merge_format)
    worksheet.write('{}{}'.format('E',xr),'In Spec %', heading_format)
    worksheet.write('{}{}'.format('F',xr),'Out of Spec %', heading_format)
    worksheet.merge_range('G{}:H{}'.format(xr-1,xr-1), 'Packetloss < {}%'.format(str(be_packetloss_threshold)), merge_format)
    worksheet.write('{}{}'.format('G',xr),'In Spec %', heading_format)
    worksheet.write('{}{}'.format('H',xr),'Out of Spec %', heading_format)
    xr += 1
    for region in regions: #be_data.keys():
        worksheet.write('{}{}'.format('A',xr),region, heading_format)
        worksheet.write('{}{}'.format('B',xr),max(r_be_Ogroups[region],be_data[region]['reflecting']))
        worksheet.write('{}{}'.format('D',xr),be_data[region]['reflecting'])
        worksheet.write('{}{}'.format('C',xr),float(max(r_be_Ogroups[region],be_data[region]['reflecting']))-float(be_data[region]['reflecting']))

        delay_in_spec = float(float(be_data[region]['dl_less_threshold'])/be_data[region]['reflecting'])
        packetloss_in_spec = float(float(be_data[region]['pl_less_threshold'])/be_data[region]['reflecting'])
        #print packetloss_in_spec
        worksheet.write('{}{}'.format('E',xr),delay_in_spec, percentage)
        worksheet.write('{}{}'.format('F',xr),float(1.00)-delay_in_spec,percentage)
        worksheet.write('{}{}'.format('G',xr),packetloss_in_spec,percentage)
        worksheet.write('{}{}'.format('H',xr),float(1.00)-packetloss_in_spec,percentage)
        xr += 1
        if region=='Total':
            worksheet.set_row(xr-2,xr-2,heading_format)
    workbook.close()
    sys.exit()
    #combine reports:
    rows=[]
    for item in data['BE']['DL']:
        tmp={}
        tmp['deviceName']=item['deviceName']
        tmp['objectName']=item['objectName'].split()[0].strip()
        #if '_SGS_' in tmp['objectName']:
        #    print tmp['objectName']
        tmp['objectDescription']=item['objectDescription']
        tmp['BE_DL']=item['data'][0]['value']/1000
        for item1 in data['BE']['PL']:
            if tmp['objectName'] in item1['objectName']:
                tmp['BE_PL']=item1['data'][0]['value']
                break
        for item1 in data['EF']['DL']:
            if tmp['objectName'] in item1['objectName']:
                tmp['EF_DL']=item1['data'][0]['value']/1000
                break
        for item1 in data['EF']['PL']:
            if tmp['objectName'] in item1['objectName']:
                tmp['EF_PL']=item1['data'][0]['value']
                break
        rows.append(tmp)
        #print tmp
    print ('Sorting complete...building XLS')
    #Build XLS
    reportName='Vodacom_Report_' + filename_date(time.time())
    workbook = xlsxwriter.Workbook(reportName + ".xlsx")
    worksheet = workbook.add_worksheet()
    number = workbook.add_format({'num_format': '0.00'})
    high_pres = workbook.add_format({'num_format': '#.#####'})
    xr=1
    xc=1
    worksheet.write('{}{}'.format('A',xr),'Region')
    worksheet.write('{}{}'.format('B',xr),'Session Name')
    worksheet.write('{}{}'.format('C',xr),'Atol ID')
    worksheet.write('{}{}'.format('D',xr),'Delay (BE)')
    worksheet.write('{}{}'.format('E',xr),'Delay (EF)')
    worksheet.write('{}{}'.format('F',xr),'Packetloss (BE)')
    worksheet.write('{}{}'.format('G',xr),'Packetloss (EF)')

    xr+=1
    for row in rows:

        if not 'EF_PL' in row.keys():
            ef_pl='---'
        else:
            ef_pl=row['EF_PL']
        if not 'EF_DL' in row.keys():
            ef_dl='---'
        else:
            ef_dl=row['EF_DL']
        if not 'BE_PL' in row.keys():
            be_pl='---'
        else:
            be_pl=row['BE_PL']    
        if not 'BE_DL' in row.keys():
            be_dl='---'
        else:
            be_dl=row['BE_DL']

        row_data=[row['deviceName'],row['objectName'],row['objectDescription'],
                  be_dl,ef_dl,be_pl,ef_pl]
        worksheet.write_row('{}{}'.format('A',xr),row_data,number)
        xr+=1
        worksheet.set_column('F:G',15,high_pres)
        worksheet.set_column(1,1,50)
workbook.close()
print (reportName)
print ('/home/willcom/{}.xlsx'.format(reportName))
#send_email('Vodacom Daily report','Hi, \n\n Please find attached the daily report.\n\n Regards \n SevOne', 'SevOne@vodacom.co.za',['rupertk@willcom.co.za'], ['/home/willcom/{}.xlsx'.format(reportName)])


