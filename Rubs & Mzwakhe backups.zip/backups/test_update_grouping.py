#!/usr/bin/env python2.7
import requests
import json
import time
import sys
import xlsxwriter

if __name__ == '__main__':
    
    rebuild=False
    if len(sys.argv)>1:
        rebuild=True

    # Log into SevOne API.
    address = 'http://10.132.98.168/api/v2/'
    creds = {'name': 'Giftm', 'password':'v0dac0m'}
    r = requests.post( address + "authentication/signin",
                       data=json.dumps( creds ),
                       headers = { 'content-type': 'application/json' })
    response = json.loads( r.text )
    #print response 
    # Open a session for credential handling.
    session = requests.Session()
    session.headers.update({ 'content-type': 'application/json',
                             'X-AUTH-TOKEN': response[ 'token' ]})
 
    # List Object Groups
    r = session.get(address + 'objectgroups?size=500&includeMembers=false')
    objects = json.loads(r.text)
    theList=[]
    for obj in objects['content']:
        #print(obj)
        if not obj['parentId'] is None:
            theList.append({"name": obj['name'],"id": obj['id']})

    OGroups_BE = [{'name': 'WES_All', 'id': 25}, {'name': 'NGA_All', 'id': 43}, 
               {'name': 'LIM_All', 'id': 45}, {'name': 'CEN_All', 'id': 56}, 
               {'name': 'KZN_All', 'id':57}, {'name': 'SGC_All', 'id': 58}, 
               {'name': 'SGS_All', 'id': 59}, {'name': 'EAS_All', 'id': 67}, 
               {'name': 'MPU_All', 'id': 279}, {'name': 'ALL_BE','id': 273},
               {'name': 'ALL_HUAWEI', 'id': 317},{'name': 'ALL_NOKIA','id':315}]
    OGroups_EF = [{'name': 'KZN_EF','id': 292}, {'name': 'ALL_EF', 'id': 272}, 
               {'name': 'SGC_EF', 'id': 293}, {'name': 'NGA_EF', 'id': 295}, 
               {'name': 'SGS_EF', 'id': 296}, {'name': 'WES_EF', 'id': 297}, 
               {'name': 'MPU_EF', 'id': 298}, {'name': 'LIM_EF', 'id': 299}, 
               {'name': 'CEN_EF', 'id': 300}, {'name': 'EAS_EF', 'id': 301},
               {'name': 'ALL_HUAWEI', 'id': 318},{'name': 'ALL_NOKIA', 'id':316}]

    #print(theList)
    # Get all sessions on SevOne
    r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(24))
    objects = json.loads(r.text)
    print (len(objects['members']))
    # Group according to BE and EF
    BE=[]
    EF=[]
    for object in objects['members']:
        #print (object['name'])
        if not ("TWAMP-TX" in object['name']) and not("86" in object['name']) and not("CDN_T" in object['name']) and not("nano" in object['name'].lower()) and not("p2p" in object['name'].lower()) and not("3g" in object['name'].lower()):
            #print (object['name'])
            if object['name'][len(object['name'])-3:] == 'BE)':
                BE.append(object)
            elif object['name'][len(object['name'])-3:] == 'EF)':
                EF.append(object)
            
    print (len(BE),len(EF))
    new_sessions_BE=[]
    new_sessions_EF=[]
    # Get all sessions on BE sessions in group 273
    r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(273))
    objects = json.loads(r.text)
    #print (len(objects['members']))
    OG_273=[]
    try:
        for object in objects['members']:
            OG_273.append(object)
    except:
        pass

    #print (len(OG_273))
    if len(OG_273)>len(BE):
        #Sessions missing from Analyser
        print ("Investigate Analyser")
    elif len(BE)>len(OG_273):
        #SevOne missing sessions
        for line in BE:
            if not (line in OG_273):
                new_sessions_BE.append(line)

    # Get all sessions on EF sessions in group 272
    r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(272))
    objects = json.loads(r.text)
    #print (len(objects['members']))
    OG_272=[]
    try:
        for object in objects['members']:
            OG_272.append(object)
    except:
        pass

    print (len(OG_273), len(OG_272))
    if len(OG_272)>len(EF):
        #Sessions missing from Analyser
        print ("Investigate Analyser")
    elif len(EF)>len(OG_272):
        #SevOne missing sessions
        for line in EF:
            if not (line in OG_272):
                new_sessions_EF.append(line)

    print (len(new_sessions_BE), len(new_sessions_EF))
    if not rebuild:
        #Add new BE sessions to OG
        for x,object in enumerate(new_sessions_BE):
            #print object
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % '273'
            #print url
            cont = 'a' #raw_input("(a)dd,(s)kip?")
            if cont == 'a':
                item = '{"deviceId":"%s","objectId":"%s"}'  % (object['deviceId'], object['id'])
                resp=session.post(url,json=json.loads(item))
                print ("Adding {}/{}: {} response:{}".format(x-1,len(new_sessions_BE)-1,item,resp.status_code))
        #Add new BE sessions to OG
        for x,object in enumerate(new_sessions_EF):
            #print object
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % '272'
            #print url
            cont = 'a' #raw_input("(a)dd,(s)kip?")
            if cont == 'a':
                item = '{"deviceId":"%s","objectId":"%s"}'  % (object['deviceId'], object['id'])
                resp=session.post(url,json=json.loads(item))
                print ("Adding {}/{}: {} response:{}".format(x-1,len(new_sessions_EF)-1,item,resp.status_code))
    else:
        print "Rebuilding grouping....this will take VERY long"
        #Rebuild all OG's with sessions.
        #Steps: 1) Delete all sessions in OG's
        #       2) Add new sessions to OG's
        #1) Delete all sessions for BE:
        for og in OGroups_BE:
            r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(og['id']))
            objects = json.loads(r.text)
            #delete sites to objectgroup
            try: 
                for x,object in enumerate(objects['members']):
                    url = "http://10.132.98.168/api/v1/objectgroups/{}/members".format(og['id'])
                    item = '{"deviceId":"%s","objectId":"%s"}'  % (object['deviceId'], object['id'])
                    resp=session.delete(url,json=json.loads(item))
                    print (item,resp.status_code, resp.text, x, len(objects['members']))
            except:
                pass
        #1) Delete all sessions for EF
        for og in OGroups_EF:
            r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(og['id']))
            objects = json.loads(r.text)
            #delete sites to objectgroup
            try: 
                for x,object in enumerate(objects['members']):
                    url = "http://10.132.98.168/api/v1/objectgroups/{}/members".format(og['id'])
                    item = '{"deviceId":"%s","objectId":"%s"}'  % (object['deviceId'], object['id'])
                    resp=session.delete(url,json=json.loads(item))
                    print (item,resp.status_code, resp.text, x, len(objects['members']))
            except:
                pass
        #2) Add new sessions to BE
        for x,session1 in enumerate(BE):
            og = 273
            og1 = 0
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % og
            item = '{"deviceId":"%s","objectId":"%s"}'  % (session1['deviceId'], session1['id'])
            resp=session.post(url,json=json.loads(item))
            print (session1['name'],item,resp.status_code, resp.text, x, len(BE))
            if '_CEN_' in session1['name']:
                og = 56
                og1 = 315
            elif '_EAS_' in session1['name']:
                og = 67
                og1 = 315
            elif '_KZN_' in session1['name']:
                og = 57
                og1 = 315
            elif '_LIM_' in session1['name']:
                og = 45
                og1 = 317
            elif '_MPU_' in session1['name']:
                og = 279
                og1 = 317
            elif '_NGA_' in session1['name']:
                og = 43
                og1 = 317
            elif '_SGS_' in session1['name']:
                og = 59
                og1 = 317
            elif '_SGC_' in session1['name']:
                og = 58
                og1 = 317
            elif '_WES_' in session1['name']:
                og = 25
                og1 = 315
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % og
            item = '{"deviceId":"%s","objectId":"%s"}'  % (session1['deviceId'], session1['id'])
            resp=session.post(url,json=json.loads(item))
            print (session1['name'],item,resp.status_code, resp.text, x, len(BE))
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % og1
            item = '{"deviceId":"%s","objectId":"%s"}'  % (session1['deviceId'], session1['id'])
            resp=session.post(url,json=json.loads(item))
            print (session1['name'],item,resp.status_code, resp.text, x, len(BE))

        #2) Add new sessions to EF
        #2) Add new sessions to BE
        for x,session1 in enumerate(EF):
            og = 272
            og1 = 0
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % og
            item = '{"deviceId":"%s","objectId":"%s"}'  % (session1['deviceId'], session1['id'])
            resp=session.post(url,json=json.loads(item))
            print (session1['name'],item,resp.status_code, resp.text, x, len(EF))
            if '_CEN_' in session1['name']:
                og = 300
                og1 = 316
            elif '_EAS_' in session1['name']:
                og = 301
                og1 = 316
            elif '_KZN_' in session1['name']:
                og = 292
                og1 = 316
            elif '_LIM_' in session1['name']:
                og = 299
                og1 = 318
            elif '_MPU_' in session1['name']:
                og = 298
                og1 = 318
            elif '_NGA_' in session1['name']:
                og = 295
                og1 = 318
            elif '_SGS_' in session1['name']:
                og = 296
                og1 = 318
            elif '_SGC_' in session1['name']:
                og = 293
                og1 = 318
            elif '_WES_' in session1['name']:
                og = 297
                og1 = 316
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % og
            item = '{"deviceId":"%s","objectId":"%s"}'  % (session1['deviceId'], session1['id'])
            resp=session.post(url,json=json.loads(item))
            print (session1['name'],item,resp.status_code, resp.text, x, len(EF))
            url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % og1
            item = '{"deviceId":"%s","objectId":"%s"}'  % (session1['deviceId'], session1['id'])
            resp=session.post(url,json=json.loads(item))
            print (session1['name'],item,resp.status_code, resp.text, x, len(EF))
            



