import os
import pexpect
import time
VCX_IP='10.132.98.169'
urs='admin'
pwd='admin'

vcx_data = ['10.132.98.169','admin','admin']

def  send_file(Filename):
     try:
	os.system("scp %s root@10.132.98.168:~/" % (Filename))
        print("sent")
     except:
	print("not sent")

#child = pexpect.spawn('ssh -o "StrictHostKeyChecking no" %s@%s' % (urs,VCX_IP))
child = pexpect.spawn('ssh -o "StrictHostKeyChecking no" %s@%s' % (vcx_data[1],vcx_data[0]))
time.sleep(1)
child.timeout = 120
print('script logging in')
child.expect('password:')
child.sendline(vcx_data[2])
print('script logged in')
child.expect(':')
child.sendline('session writelock')
child.expect(':')
child.sendline('remote-devices show Proxy-9059\n')
time.sleep(10)
child.expect(':')
data = child.before
itemData = data.split('\r\n')
print(itemData)

