import os
import sys
import datetime
import time
import shutil
import glob
import subprocess
from pexpect import *
from pexpect import pxssh

latest_timestamp = 0
latest_report = None

def search_report():
    global latest_timestamp
    global latest_report
    global filename

    for fileattr in os.listdir("/home/willcom"):
         if fileattr.startswith('Vodacom_Report_{}'.format(datetime.datetime.fromtimestamp(int(time.time())).strftime('%Y_%m_%d'))) and os.path.getmtime(fileattr) > latest_timestamp:
             latest_timestamp = os.path.getmtime(fileattr)
             latest_report = ''.join(os.path.splitext(fileattr))
             print(latest_report)

def main():
    search_report()
    cmd_scp = "scp %s root@10.132.98.168:~/" % (latest_report)
    server_pass = "dRum&5853"
 
    ssh = pxssh.pxssh()
    ssh.login('10.132.98.168', 'root', server_pass)

    ssh.sendline('scp willcom@10.13.56.190:%s ~/' % (latest_report))
    ssh.prompt()
    print(ssh.before)
    ssh.sendline('yes')
    ssh.prompt()
    ssh.sendline('w1llc0m')
    ssh.prompt() 
    print(ssh.before)
    ssh.sendline('python send_report_via_email.py')
    ssh.prompt()
    print(ssh.before)
    
main()
