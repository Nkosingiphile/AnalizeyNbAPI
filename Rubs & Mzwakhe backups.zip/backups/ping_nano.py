import sys
import pexpect
import time
import os

VCX_IP='10.132.98.169'
urs='admin'
pwd='admin'

vcx_data = ['10.132.98.169','admin']

def  send_file(Filename):
     try:
	os.system("scp %s root@10.132.98.168:~/" % (Filename))
        print("sent")
     except:
	print("not sent")

#child = pexpect.spawn('ssh -o "StrictHostKeyChecking no" %s@%s' % (urs,VCX_IP))
child = pexpect.spawn('ssh -o "StrictHostKeyChecking no" %s@%s' % (vcx_data[1],vcx_data[0]))
time.sleep(1)
child.timeout = 120
print('script logging in')
child.expect('password:')
child.sendline(vcx_data[1])
print('script logged in')
child.expect(':')
child.sendline('session writelock')
child.expect(':')
child.sendline('util-tool echo icmp interface Traffic address 10.246.224.179')
time.sleep(2)
child.expect(':')
data = child.before
itemData = data.split('\r\n')
print(itemData[5])

if itemData[5] == "> Warning":
	print(" Nano not rechable, script will send mail")
        file_to_send = open("test_ping.txt", "w")
        file_to_send.write(itemData[5] + " nano 10.246.224.179 not reacheable")
        file_to_send.close()
else:
	print("not sending email")

filename = "test_ping.txt"
send_file(filename)
