#!/usr/bin/env python
import requests
import json
import time
import sys
import xlsxwriter

if __name__ == '__main__':
    
    try:
        output_base = sys.argv[1]
    except:
        output_base = 'report'

    OGroups_BE = [{'name': 'WES_All', 'id': 25}, {'name': 'NGA_All', 'id': 43}, 
               {'name': 'LIM_All', 'id': 45}, {'name': 'CEN_All', 'id': 56}, 
               {'name': 'KZN_All', 'id':57}, {'name': 'SGC_All', 'id': 58}, 
               {'name': 'SGS_All', 'id': 59}, {'name': 'EAS_All', 'id': 67}, 
               {'name': 'MPU_All', 'id': 279}, {'name': 'ALL_BE','id': 273}]
    OGroups_EF = [{'name': 'KZN_EF','id': 292}, {'name': 'ALL_EF', 'id': 272}, 
               {'name': 'SGC_EF', 'id': 293}, {'name': 'NGA_EF', 'id': 295}, 
               {'name': 'SGS_EF', 'id': 296}, {'name': 'WES_EF', 'id': 297}, 
               {'name': 'MPU_EF', 'id': 298}, {'name': 'LIM_EF', 'id': 299}, 
               {'name': 'CEN_EF', 'id': 300}, {'name': 'EAS_EF', 'id': 301}]
    
    # Log into SevOne API.
    address = 'http://10.132.98.168/api/v2/'
    creds = {'name': 'krugerrc', 'password':'Desre001!'}
    r = requests.post( address + "authentication/signin",
                       data=json.dumps( creds ),
                       headers = { 'content-type': 'application/json' })
    response = json.loads( r.text )
    #print response 
    # Open a session for credential handling.
    session = requests.Session()
    session.headers.update({ 'content-type': 'application/json',
                             'X-AUTH-TOKEN': response[ 'token' ]})
 
    outfile = output_base + "_BE_sessions.xlsx"
    workbook = xlsxwriter.Workbook(outfile)
    
    for region in OGroups_BE:
        # Get ObjectGroup 
        r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(region['id']))
        objects = json.loads(r.text)
        print ('Processing {}'.format(region['id']))
        row=0
        col=0
        worksheet = workbook.add_worksheet(name=region['name'])
        worksheet.write_row(row,col,['Session Name','Session ID','Atol ID','VCX ID', 'Region ID'])
        for myobject in objects['members']:
            print myobject
            row+=1
            worksheet.write_row(row,col,[myobject['name'],myobject['id'],myobject['description'],myobject['deviceId'],region['id']])

    workbook.close()
    print ("Done - Saved output to %s" % outfile)

    outfile = output_base + "_EF_sessions.xlsx"
    workbook = xlsxwriter.Workbook(outfile)

    for region in OGroups_EF:
        # Get ObjectGroup 
        r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(region['id']))
        objects = json.loads(r.text)
        print ('Processing {}'.format(region['id']))
        row=0
        col=0
        worksheet = workbook.add_worksheet(name=region['name'])
        worksheet.write_row(row,col,['Session Name','Session ID','Atol ID','VCX ID', 'Region ID'])
        for myobject in objects['members']:
            print myobject
            row+=1
            worksheet.write_row(row,col,[myobject['name'],myobject['id'],myobject['description'],myobject['deviceId'],region['id']])

    workbook.close()
    print ("Done - Saved output to %s" % outfile)


