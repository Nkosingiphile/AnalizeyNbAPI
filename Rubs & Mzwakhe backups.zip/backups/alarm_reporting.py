import pexpect
import time
from pexpect import pxssh

"""child = pexpect.spawn('ssh  %s@%s' % ('admin','10.132.98.169'))
time.sleep(1)
child.timeout = 120
print('script logging in')
child.expect('password:')
child.sendline('admin')
print('script logged in')
child.expect(':')
child.sendline('session writelock')
child.expect(':')
child.sendline('remote-devices show Proxy-9059')
child.expect(':')
items = child.before
print(type(items))
print(items)
"""

ssh = pxssh.pxssh()
ssh.login('10.132.98.169', 'admin', 'admin')
#ssh.sendline('session writelock')
#ssh.prompt()
print(ssh.before)
#ssh.sendline('remote-devices show Proxy-9059')
#ssh.prompt()
#print(ssh.before)

