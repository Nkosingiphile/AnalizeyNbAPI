import requests
import json
import sys


region = sys.argv[1]
filename = sys.argv[2]
og = sys.argv[3]

search_sites=[]
with open(filename) as f:
    search_sites=f.read().splitlines()

print search_sites

url1 = "http://10.132.98.168/api/v1/authentication/signin"
item = '{"name":"%s","password":"%s"}'  % ("admin", "v0dac0m")
resp=requests.post(url1,json=json.loads(item))
results=json.loads(resp.content)
token = results['token']

url1 = "http://10.132.98.168/api/v1/devices?size=20"
headers = {"X-AUTH-TOKEN":"%s" % token}
print headers
resp = requests.get(url1,headers=headers)

results=json.loads(resp.content)
devices=[]

for device in results['content']:
    tmp={}
    tmp['id']=device['id']
    tmp['name']=device['name']
    if device['name']==region:
        devices.append(tmp)
        break

object_list=[]
tmpobjects=[]
unknown=[]
for device in devices:
    url1 = "http://10.132.98.168/api/v1/devices/%s/objects?size=5000&includeIndicators=false&includeExtendedInfo=true" % device['id']
    resp = requests.get(url1,headers=headers)
    results=json.loads(resp.content)
    #tmp={}
    #tmpobjects=[]
    print results['totalElements']
   
    for objects in results['content']:
        tmpobject={}
        
        aName = objects['name'].split()[1].strip().strip("(").strip(")").strip()[4:]
        print objects['name'], aName
        for site in search_sites:
            #if not 'Nokia' in objects['name'] and not site=='' and not "Nano" in objects['name']:
            removed=site.strip('"').strip('VM_')
            #print removed
            if removed.strip() in aName:
                print site, ",", objects['name']
                tmpobject['id']=objects['id']
                tmpobject['name']=objects['name']
                tmpobjects.append(tmpobject)

print len(tmpobjects),len(search_sites)


#add sites to objectgroup 
#for object in tmpobjects:
#    url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % og
#    item = '{"deviceId":"%s","objectId":"%s"}'  % (devices[0]["id"], object['id'])
#    resp=requests.post(url,headers=headers,json=json.loads(item))
#    print resp.status_code
