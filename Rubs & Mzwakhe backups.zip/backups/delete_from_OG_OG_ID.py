import requests
import json
import sys


#filename = sys.argv[1]

objectGroupID = sys.argv[1].split()[0]

address = 'http://10.132.98.168/api/v2/'
creds = {'name': 'admin', 'password':'v0dac0m'}
r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
response = json.loads( r.text )

session = requests.Session()
session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})
 
    # Get ObjectGroup 
r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(objectGroupID))
objects = json.loads(r.text)
#add sites to objectgroup 
for x,object in enumerate(objects['members']):
    url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % objectGroupID.strip()
    #print url
    cont = 'a' #raw_input("(a)dd,(s)kip?")
    if cont == 'a':
        item = '{"deviceId":"%s","objectId":"%s"}'  % (object['deviceId'], object['id'])
        resp=session.delete(url,json=json.loads(item))
        print (item,resp.status_code, resp.text, x, len(objects['members']))