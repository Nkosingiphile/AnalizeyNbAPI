#!/usr/bin/env python
#from __future__ import print_function
import pexpect
import sys
import time

def single_line(data):
    sys.stdout.write('%s\r' % data)
    sys.stdout.flush()

def get_status(pexp,session):
    pexp.timeout = 20
    cmd = 'show session TWAMP %s' % session
    #print cmd
    pexp.sendline(cmd)
    #time.sleep(8)
    pexp.expect('#')
    response = pexp.before
    if 'Running' in response:
        #print "running: " , response
        blocks = response.split('Running')[-1].split('\r\n')
        #print blocks
        try:
            row2 = blocks[2].strip().split()
            row4 = blocks[4].strip().split()
            if not 'Error' in row2 and not 'errcode:' in row2:
                #print row2,row4
                feedback = ",%s,%s" % (row2[3].split(':')[1],row4[3].split(':')[1])
            else:
                feedback = ',-99,-99'
        except Exception as e:
            feedback = ',-99,-99'
            pass
    else:
        feedback = ',n/a,n/a'
    print feedback
    return feedback

if __name__ == '__main__':

    if not len(sys.argv)==5:
        print("Usage:")
        print("      python auditAnalyzer.py <Analyzer Server IP> <Analyzer Username> <Analyzer Password> <Output filename>")
        print("Example:") 
        print("      python auditAnalyzer.py 10.132.98.167 vodacom vodacom ~/output.csv")
    else:
        server = sys.argv[1]
        uname = sys.argv[2]
        pwd = sys.argv[3]
        filename=sys.argv[4]
        print "Logging in..."
        child = pexpect.spawn(
                    'ssh -o "StrictHostKeyChecking no" %s@%s' % (uname, server))
        time.sleep(1)
        child.timeout = 120
        child.expect('Password:')
        child.sendline(pwd)
        child.expect('#')
        #print child.before
        child.sendline('mgr-commands')
        child.expect('#')
        #print child.before
        print("Collecting session info...")
        child.timeout = None
        child.sendline('show sessions all')
        time.sleep(5)
        child.expect('#')
        #child.expect('#')
        data = child.before
        itemData = data.split('\r\n')

        #print itemData[-1]
        #print itemData[-2]
        Data = itemData[2:-3]
        items=[]
        print("Writing to file...")
        testSession = ''
        with open(filename,'w') as f:
            f.write('Session Name,State,Stream,Sender,Status,Endpoint,PPS,Payload,Sender IP,Endpoint IP, p2r Loss, r2p Loss\n') 
            for x in xrange(3,len(Data)-1,2):
                myStr = "Executing session %s of %s" % (str(x),str((len(Data)-1)))
                #print "\033[K", myStr, "\r",
                #sys.stdout.flush()
                single_line(myStr)
                #print(myStr, end='')
                #sys.stdout.flush()
                line1=Data[x].strip().split()
                line2=Data[x-1].strip().split()
                testSession = line2[0]
                line1=','.join(line1)
                line2=','.join(line2)
                feedback = get_status(child,testSession)
                f.write(line2+','+line1+feedback+'\n')

        #Exit Analyser
        child.sendline('exit')
        child.expect('#')
        child.sendline('exit')

        print("Completed...saved to %s" % filename)
