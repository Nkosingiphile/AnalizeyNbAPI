import requests
import json
import sys


#region = sys.argv[1]
Atholl_filename = sys.argv[1]
AthollInfo=[]
with open(Atholl_filename) as f:
    AthollInfo=f.read().splitlines()

# Log into SevOne API.
address = 'http://10.132.98.168/api/v2/'
creds = {'name': 'Giftm', 'password':'v0dac0m'}
r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
response = json.loads( r.text )
#print response 
# Open a session for credential handling.
session = requests.Session()
session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})
fixed=[]
for athol_object in AthollInfo:
    athol = athol_object.split(',')
    if not 1==0:
        url = 'http://10.132.98.168/api/v2/devices/%s/objects/%s' % (athol[1].strip(),athol[0].strip())
        print url
        data = '{\n  "description": "%s"\n}' % athol[5].strip()
        print data
        response = session.patch(url, data=data) 
        print response

