import requests
import json
import sys


filename = sys.argv[1]

sites=[]
with open(filename) as f:
    sites=f.read().splitlines()

url1 = "http://10.132.98.168/api/v1/authentication/signin"
item = '{"name":"%s","password":"%s"}'  % ("admin", "v0dac0m")
resp=requests.post(url1,json=json.loads(item))
results=json.loads(resp.content)
token = results['token']

url1 = "http://10.132.98.168/api/v1/devices?size=20"
headers = {"X-AUTH-TOKEN":"%s" % token}
print headers
resp = requests.get(url1,headers=headers)

results=json.loads(resp.content)
devices=[]

#add sites to objectgroup 
for object in sites:
    print object
    parts=object.split(',')
    url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % parts[9].strip()
    #print url
    cont = 'a' #raw_input("(a)dd,(s)kip?")
    if cont == 'a':
        item = '{"deviceId":"%s","objectId":"%s"}'  % (parts[8].strip(), parts[7].strip())
        resp=requests.delete(url,headers=headers,json=json.loads(item))
        print item,resp

