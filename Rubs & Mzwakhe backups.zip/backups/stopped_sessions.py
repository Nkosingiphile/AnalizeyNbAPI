#!/usr/bin/env python
#from __future__ import print_function
import pexpect
import sys
import time

def single_line(data):
    sys.stdout.write('%s\r' % data)
    sys.stdout.flush()

if __name__ == '__main__':

    if not len(sys.argv)==5:
        print("Usage:")
        print("      python stopped_sessions.py <Analyzer Server IP> <Analyzer Username> <Analyzer Password> <Output filename>")
        print("Example:") 
        print("      python stopped_sessions.py 10.132.98.167 vodacom vodacom ~/output.csv")
    else:
        server = sys.argv[1]
        uname = sys.argv[2]
        pwd = sys.argv[3]
        filename=sys.argv[4]
        print "Logging in..."
        child = pexpect.spawn(
                    'ssh -o "StrictHostKeyChecking no" %s@%s' % (uname, server))
        time.sleep(1)
        child.timeout = 120
        child.expect('Password:')
        child.sendline(pwd)
        child.expect('#')
        #print child.before
        child.sendline('mgr-commands')
        child.expect('#')
        #print child.before
        print("Collecting session info...")
        child.timeout = None
        child.sendline('show session state Error')
        time.sleep(5)
        child.expect('#')
        #child.expect('#')
        data = child.before
        child.sendline('show session state Terminated')
        time.sleep(5)
        child.expect('#')
        #child.expect('#')
        data1 = child.before
        itemData = data.split('\r\n')
        itemData1 = data1.split('\r\n')
        #print itemData[-1]
        #print itemData[-2]
        Data = itemData[2:-3]
        Data1 = itemData1[2:-3]
        #print Data
        #raw_input('...')
        #print Data1
        #raw_input('...')
        items=[]
        print("Writing to file...")
        testSession = ''
        #print len(Data)
        #raw_input('key to continue...')
        sessions=[]
        Data = Data + Data1
        with open(filename,'w') as f:
            f.write('Session Name,State,Stream,Sender,Status,Endpoint,PPS,Payload,Sender IP,Endpoint IP, p2r Loss, r2p Loss\n') 
            for x in xrange(3,len(Data)-1,2):
                myStr = "Executing session %s of %s" % (str(x),str((len(Data)-1)))
                #print "\033[K", myStr, "\r",
                #sys.stdout.flush()
                single_line(myStr)
                #print(myStr, end='')
                #sys.stdout.flush()
                line1=Data[x].strip().split()
                line2=Data[x-1].strip().split()
                line1=','.join(line1)
                line2=','.join(line2)
                sessions.append(line2.split(',')[0])
                f.write(line2+','+line1 + '\n')
                #print "{}, {}".format(line2,line1)

        

        print("Completed...saved to %s" % filename)
        restart = 'y' #raw_input('Restart Sessions? (y/n)')
        if restart == 'n':
            sys.exit()
        for x,session in enumerate(sessions):
            cmd = 'operate session {} stop'.format(session.strip())
            #print("Session {} of {} {}".format(x+1,len(sessions),cmd))
            child.sendline(cmd)
            child.expect('#')
            print("         {}".format(child.before))
            cmd = 'operate session {} terminate'.format(session.strip())
            #print("Session {} of {} {}".format(x+1,len(sessions),cmd))
            child.sendline(cmd)
            child.expect('#')
            print("         {}".format(child.before))
            cmd = 'operate session {} start'.format(session.strip())
            #print("Session {} of {} {}".format(x+1,len(sessions),cmd))
            child.sendline(cmd)
            time.sleep(1)
            child.expect('#')
            #child.expect('#')
            print("         {}".format(child.before))        
        #Exit Analyser
        child.sendline('exit')
        child.expect('#')
        child.sendline('exit')
        print "+------------------------------------------+"
        print "|                                          |"
        print "|         {} sessions restarted            |".format(len(sessions))
        print "|                                          |"
        print "+------------------------------------------+"
