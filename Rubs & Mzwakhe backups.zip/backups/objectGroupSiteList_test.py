#!/usr/bin/env python
import requests
import json
import time
import sys
import xlsxwriter

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders
import os
import time
import datetime
import random

def generate_message_id(msg_from):
    domain = msg_from.split("@")[1]
    r = "%s.%s" % (time.time(), random.randint(0, 100))
    mid = "<%s@%s>" % (r, domain)
    return mid

def sendMail(msg_from, to, subject, text,files=[],server="localhost", debug=False):
    assert type(to)==list
    assert type(files)==list

    msg = MIMEMultipart()
    msg['From'] = msg_from
    msg['To'] = COMMASPACE.join(to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    text = text.encode("utf-8")
    text = MIMEText(text, 'plain', "utf-8")
    msg.attach(text)

    msg.add_header('Message-ID', generate_message_id(msg_from))

    for file in files:
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(file,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"'
                       % os.path.basename(file))
        msg.attach(part)

    if not debug:
        smtp = smtplib.SMTP('10.74.25.17')
        smtp.sendmail(msg_from, to, msg.as_string())
        smtp.close()

    return msg

if __name__ == '__main__':


    objectGroupID = sys.argv[1].split()[0]
    outputFile = sys.argv[1].split()[1] + "_" + sys.argv[2]
    
    # Log into SevOne API.
    address = 'http://10.132.98.168/api/v2/'
    creds = {'name': 'admin', 'password':'v0dac0m'}
    r = requests.post( address + "authentication/signin",
                       data=json.dumps( creds ),
                       headers = { 'content-type': 'application/json' })
    response = json.loads( r.text )
    #print response 
    # Open a session for credential handling.
    session = requests.Session()
    session.headers.update({ 'content-type': 'application/json',
                             'X-AUTH-TOKEN': response[ 'token' ]})
 
    # Get ObjectGroup 
    r = session.get(address + 'objectgroups/{}?includeMembers=true'.format(objectGroupID))
    objects = json.loads(r.text)

    with open(outputFile,'w') as f:
        f.write("Session Name, Session ID, Atholl ID, Device ID\n")
        for object in objects['members']:
            #if not ("TWAMP-TX" in object['name']) and not("86" in object['name']) and not("CDN_T" in object['name']) and not("nano" in object['name'].lower()) and not("3g" in object['name'].lower()):
            f.write("%s, %s, %s, %s, %s\n" % (object['name'],object['id'],object['description'],object['deviceId'],str(objectGroupID)))
            print object['name'], object['id'],object['description'],object['deviceId'],objectGroupID

    print"Done - Saved output to %s" % outputFile
