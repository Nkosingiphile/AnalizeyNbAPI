import requests
import json
import sys

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
import os
import datetime
import random
from email import encoders

url1 = "http://10.132.98.168/api/v1/authentication/signin"
item = '{"name":"%s","password":"%s"}'  % ("MzwakheB", "v0dac0m")
resp=requests.post(url1,json=json.loads(item))
results=json.loads(resp.content)
token = results['token']

ID = [
    "10538783",
    "10538781"
    ]

def send_email():
    fromaddr = "mzwakheb@willcom.co.za"
    toaddr = "giftm@willcom.co.za"
    
    msg = MIMEMultipart()
    
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Alerts"
    
    body = messageAlert
    
    msg.attach(MIMEText(body, 'plain'))
    reportName = "test.xlsx"
    filename = "{}".format(reportName)
    attachment = open(filename, "rb")
    
    part = MIMEBase('application', 'octet-stream')
    part.set_payload((attachment).read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
    
    msg.attach(part)
    
    server = smtplib.SMTP('10.74.25.17', 1025) #'smtp.office365.com', 587
    server.set_debuglevel(1)
    server.ehlo()
    server.starttls()
    #server.login(fromaddr, "R3qu3st3r2014")
    text = msg.as_string()
    server.sendmail(fromaddr, toaddr, text)
    server.quit()

for i in ID:
    url1 = "http://10.132.98.168/api/v2/alerts/%s" %i
    headers = {"X-AUTH-TOKEN":"%s" % token}
    resp = requests.get(url1,headers=headers)

    results=json.loads(resp.content)

    sessionID = results.get('id')
    severityOfSession = results.get('severity')
    messageAlert = results.get('message')

    print(sessionID)
    print(severityOfSession)
    print(messageAlert)
send_email()

