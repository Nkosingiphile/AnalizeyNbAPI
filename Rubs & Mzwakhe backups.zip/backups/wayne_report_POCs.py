import requests
import json
import time
import datetime
import sys
import xlsxwriter

import smtplib
#import os.path
from email.MIMEMultipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
import os
import datetime
import random

def send_email(subject, message, from_email, to_email=[], attachment=[]):
    """
    :param subject: email subject
    :param message: Body content of the email (string), can be HTML/CSS or plain text
    :param from_email: Email address from where the email is sent
    :param to_email: List of email recipients, example: ["a@a.com", "b@b.com"]
    :param attachment: List of attachments, exmaple: ["file1.txt", "file2.txt"]
    """
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = ", ".join(to_email)
    msg.attach(MIMEText(message, 'html'))

    for f in attachment:
        with open(f, 'rb') as a_file:
            basename = os.path.basename(f)
            part = MIMEApplication(a_file.read(), Name=basename)

        part['Content-Disposition'] = 'attachment; filename="%s"' % basename
        msg.attach(part)

    email = smtplib.SMTP('10.74.25.17')
    email.sendmail(from_email, to_email, msg.as_string())

def readable_date(timestamp):
    readable_time = datetime.datetime.fromtimestamp(int(timestamp)/1000).strftime('%Y-%m-%d %H:%M:%S')
    return readable_time

def filename_date(timestamp):
    filename_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime('%Y_%m_%d__%H-%M-%S')
    return filename_date
if __name__ == "__main__":
    print datetime.datetime.now()

    #Get BSC Names
    bsc_names = []
    #with open('BSC_Names.csv','r') as f:
    #    bsc_names = f.read().splitlines()
    #print bsc_names
    address = 'http://10.132.98.168/api/v2/'
    creds = {'name': 'Giftm', 'password':'v0dac0m'}
    r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
    response = json.loads( r.text )

# Open a session for credential handling.
    session = requests.Session()
    session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})
 

    reports={'BE': {'DL': '1671', 'PL': '1690'}}
    data={}
    for report_key in reports.keys():
        dl_id=reports[report_key]['DL']
        pl_id=reports[report_key]['PL']

        data[report_key]={}
        r = session.get(address + 'reports/attachments/topn/{}/run'.format(dl_id))
        data[report_key]['DL'] = json.loads(r.text)['result']
        r = session.get(address + 'reports/attachments/topn/{}/run'.format(pl_id))
        data[report_key]['PL'] = json.loads(r.text)['result']
    print data.keys()
    print data['BE'].keys()
    print len(data['BE']['DL']),len(data['BE']['PL'])
    #print data['BE']['PL']
    #sys.exit()
    #combine reports:
    rows=[]
    for item in data['BE']['DL']:
        tmp={}
        tmp['deviceName']=item['deviceName']
        tmp['objectName']=item['objectName'].split()[0].strip()
        #if '_SGS_' in tmp['objectName']:
        #    print tmp['objectName']
        tmp['objectDescription']=item['objectDescription']
        tmp['BE_DL']=item['data'][0]['value']/1000
        for item1 in data['BE']['PL']:
            if tmp['objectName'] in item1['objectName']:
                tmp['BE_PL']=item1['data'][0]['value']
                break
        #for item1 in data['EF']['DL']:
        #    if tmp['objectName'] in item1['objectName']:
        #        tmp['EF_DL']=item1['data'][0]['value']/1000
        #        break
        #for item1 in data['EF']['PL']:
        #    if tmp['objectName'] in item1['objectName']:
        #        tmp['EF_PL']=item1['data'][0]['value']
        #        break
        rows.append(tmp)
        #print tmp
    print 'Sorting complete...building XLS'
    #Build XLS
    reportName='Vodacom_POCs_Report_' + filename_date(time.time())
    workbook = xlsxwriter.Workbook(reportName + ".xlsx")
    worksheet = workbook.add_worksheet()
    number = workbook.add_format({'num_format': '0.00'})
    high_pres = workbook.add_format({'num_format': '#.#####'})
    xr=2
    xc=1
    worksheet.write('{}{}'.format('A',xr),'Region')
    worksheet.write('{}{}'.format('B',xr),'Session Name')
    worksheet.write('{}{}'.format('C',xr),'Atol ID')
    worksheet.write('{}{}'.format('D',xr),'Delay (BE)')
    #worksheet.write('{}{}'.format('E',xr),'Delay (EF)')
    worksheet.write('{}{}'.format('E',xr),'Packetloss (BE)')
    #worksheet.write('{}{}'.format('G',xr),'Packetloss (EF)')
    #worksheet.write('{}{}'.format('F',xr),'BSC-1')

    xr+=1
    for row in rows:

        #if not 'EF_PL' in row.keys():
        #    ef_pl='---'
        #else:
        #    ef_pl=row['EF_PL']
        #if not 'EF_DL' in row.keys():
        #    ef_dl='---'
        #else:
        #    ef_dl=row['EF_DL']
        if not 'BE_PL' in row.keys():
            be_pl='---'
        else:
            be_pl=row['BE_PL']    
        if not 'BE_DL' in row.keys():
            be_dl='---'
        else:
            be_dl=row['BE_DL']
        #Find BSC"
        #bsc_n = '#N/A'
        #for bsc in bsc_names:
        #    atol_id = bsc.split(',')[0].strip()
        #    if atol_id == row['objectDescription'].strip():
        #        bsc_n = bsc.split(',')[9].strip()
        #        break

        row_data=[row['deviceName'],row['objectName'],row['objectDescription'],
                  be_dl,be_pl] #,ef_dl,be_pl,ef_pl, bsc_n]
        worksheet.write_row('{}{}'.format('A',xr),row_data,number)
        xr+=1
        worksheet.set_column('D:E',15,high_pres)
        worksheet.set_column(1,1,50)
    workbook.close()
    print reportName
    print '/home/willcom/{}.xlsx'.format(reportName)
#send_email('Vodacom Daily report','Hi, \n\n Please find attached the daily report.\n\n Regards \n SevOne', 'SevOne@vodacom.co.za',['rupertk@willcom.co.za'], ['/home/willcom/{}.xlsx'.format(reportName)])

