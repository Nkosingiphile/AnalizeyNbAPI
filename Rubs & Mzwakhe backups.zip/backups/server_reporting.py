import sys
import pexpect
from pexpect import pxssh
import time
import os

""" VCX_IP='10.132.98.169'
urs='admin'
pwd='admin' """

VCX_IP = ['10.132.98.169']
VCX_USR = ['admin']
VCX_PWD = ['admin']

NANO_IP = ['10.246.224.179'] #, '10.246.224.179']

VCX_DATA = len(VCX_IP)
#NANO_DATA = len(NANO_IP)

def send_file_SevOne(Filename):
     try:
        server_pass = "dRum&5853"
     
        ssh = pxssh.pxssh()
        ssh.login('10.132.98.168', 'root', server_pass)

        ssh.sendline('scp willcom@10.13.56.190:%s ~/' % (Filename))
        ssh.prompt()
        print(ssh.before)
        ssh.sendline('w1llc0m')
        ssh.prompt() 
        print(ssh.before)
        ssh.sendline('python send_alert_via_email.py')
        ssh.prompt()
        print(ssh.before)
     except:
        print("not sent")

def send_file_Pi(FileName):
     try:
        server_pass = "R3qu3st3r2014"
     
        ssh = pxssh.pxssh()
        ssh.login('10.133.199.167', 'mzwakhe', server_pass)

        ssh.sendline('scp willcom@10.13.56.190:%s ~/' % (FileName))
        ssh.prompt()
        print(ssh.before)
        ssh.sendline('w1llc0m')
        ssh.prompt() 
        print(ssh.before)
     except:
        print("not sent")

def main():
    for x in range(VCX_DATA):
        child = pexpect.spawn('ssh  %s@%s' % (VCX_USR[x], VCX_IP[x]))
        time.sleep(1)
        child.timeout = 120
        print('script logging in')
        child.expect('password:')
        child.sendline(VCX_PWD[x])
        print('script logged in')
        child.expect(':')
        child.sendline('session writelock')
        child.expect(':')
        NANO_DATA = len(NANO_IP)
        for y in range(NANO_DATA):
            print(y)
            child.sendline('util-tool echo icmp interface Traffic address %s' % (NANO_IP[y]))
            time.sleep(2)
            child.expect(':')
        data = child.before
        print(data)
        itemData = data.split('\r\n')
        print(itemData[5])

        if itemData[5] == "> Warning":
               print(" Nano not rechable, script will send mail")
               file_to_send = open("test_ping.txt", "w")
               file_to_send.write(itemData[5] + " nano %s not reacheable" % (NANO_IP[y]))
               file_to_send.close()
        else:
           print("not sending email")

    filename = "test_ping.txt"
    send_file_SevOne(filename)
    send_file_Pi(filename)

main()
               












            
        
