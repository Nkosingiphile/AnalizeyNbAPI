import sys
import pexpect
import time
#import CSV
#import smptlib


Lts_IP='192.168.7.211'
urs='admin'
pwd='admin'

child = pexpect.spawn('ssh -o "StrictHostKeyChecking no" %s@%s' % (urs,Lts_IP))
time.sleep(1)
child.timeout = 20
print('script logging in')
child.expect('password:')
child.sendline(pwd)
print('script logged in')
child.expect(':')
child.sendline('session writelock')
#child.expect(':')
#child.sendline('reboot')

def ReadNanoInfo():
	with open ('Nano_ANT_Prestage.csv','r') as f:
		dataf=[]
		#dataf=csv.reader(f)
		dataf= f.read().splitlines()
		#print dataf
		
		for info in dataf:
			inf= info.split(',')
			print inf
			for result in inf[4:7]:
				#print('--------------------Expect--------------')
	            		child.expect(':')
				print result						
				child.sendline(inf[4])
				child.sendline(inf[5])
				child.sendline(inf[6])
				child.sendline(inf[7])
		
ReadNanoInfo()
print('                                                                                                        ')
print('------------------------------------congradulation,prestaging is done---------------------------------')
