import requests
import json
import time
import datetime
import sys
import xlsxwriter

import smtplib
#import os.path
import os
import datetime
import random

def readable_date(timestamp):
    readable_time = datetime.datetime.fromtimestamp(int(timestamp)/1000).strftime('%Y-%m-%d %H:%M:%S')
    return readable_time

def filename_date(timestamp):
    filename_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime('%Y_%m_%d__%H-%M-%S')
    return filename_date
if __name__ == "__main__":
    print(datetime.datetime.now())

    #Get BSC Names
    bsc_names = []
    with open('BSC_Names.csv','r') as f:
        bsc_names = f.read().splitlines()
    #print bsc_names
    address = 'http://10.132.98.168/api/v2/'
    creds = {'name': 'Giftm', 'password':'v0dac0m'}
    r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
    response = json.loads( r.text )

# Open a session for credential handling.
    session = requests.Session()
    session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})
 

    reports={'BE': {'DL': '1694,1695',  'PL': '1698,1699', 'JT' : '1700,1703'}, 'EF': {'DL': '1692,1693', 'PL': '1696,1697', 'JT' : '1701,1702'}}
    data={}
    for report_key in reports.keys():
        ids = reports[report_key]['DL'].split(',')
        dl_id1=ids[0]
        dl_id2=ids[1]
        ids=reports[report_key]['PL'].split(',')
        pl_id1=ids[0]
        pl_id2=ids[1]
        ids=reports[report_key]['JT'].split(',')
        jt_id1=ids[0]
        jt_id2=ids[1]

        data[report_key]={}
        r1 = session.get(address + 'reports/attachments/topn/{}/run'.format(dl_id1))
        r2 = session.get(address + 'reports/attachments/topn/{}/run'.format(dl_id2))
        data1 = json.loads(r1.text)['result']
        #print data[report_key]['DL'][0]
        #sys.exit()
        data2 = json.loads(r2.text)['result']
        data[report_key]['DL'] = data1 + data2
        
        #r = session.get(address + 'reports/attachments/topn/{}/run'.format(pl_id1))
        #data[report_key]['PL'] = json.loads(r.text)['result']
        r1 = session.get(address + 'reports/attachments/topn/{}/run'.format(pl_id1))
        r2 = session.get(address + 'reports/attachments/topn/{}/run'.format(pl_id2))
        data1 = json.loads(r1.text)['result'] 
        data2 = json.loads(r2.text)['result']
        data[report_key]['PL'] = data1 + data2
        
        r1 = session.get(address + 'reports/attachments/topn/{}/run'.format(jt_id1))
        r2 = session.get(address + 'reports/attachments/topn/{}/run'.format(jt_id2))
        data1 = json.loads(r1.text)['result'] 
        data2 = json.loads(r2.text)['result']
        data[report_key]['JT'] = data1 + data2

        
    print(data.keys())
    print(data['BE'].keys(),data['EF'].keys())
    print(len(data['BE']['DL']),len(data['BE']['PL']),len(data['BE']['JT']),len(data['EF']['DL']),len(data['EF']['PL']),len(data['EF']['JT']))
    #print data['BE']['DL'][0],data['EF']['DL'][0]
    #sys.exit()
    #combine reports:
    rows=[]
    for item in data['BE']['DL']:
        tmp={}
        tmp['deviceName']=item['deviceName']
        tmp['objectName']=item['objectName'].split()[0].strip()
        #if '_SGS_' in tmp['objectName']:
        #    print tmp['objectName']
        tmp['objectDescription']=item['objectDescription']
        tmp['BE_DL']=item['data'][0]['value']/1000
        for item1 in data['BE']['PL']:
            if tmp['objectName'] in item1['objectName']:
                tmp['BE_PL']=item1['data'][0]['value']
                break
        for item1 in data['BE']['JT']:
            if tmp['objectName'] in item1['objectName']:
                tmp['BE_JT']=item1['data'][0]['value']/1000
                break
        for item1 in data['EF']['DL']:
            if tmp['objectName'] in item1['objectName']:
                tmp['EF_DL']=item1['data'][0]['value']/1000
                break
        for item1 in data['EF']['PL']:
            if tmp['objectName'] in item1['objectName']:
                tmp['EF_PL']=item1['data'][0]['value']
                break
        for item1 in data['EF']['JT']:
            if tmp['objectName'] in item1['objectName']:
                tmp['EF_JT']=item1['data'][0]['value']/1000
                break
        rows.append(tmp)
        #print tmp
    print('Sorting complete...building XLS')
    #Build XLS
    reportName='Vodacom_Report_' + filename_date(time.time())
    workbook = xlsxwriter.Workbook(reportName + ".xlsx")
    worksheet = workbook.add_worksheet()
    number = workbook.add_format({'num_format': '0.00'})
    high_pres = workbook.add_format({'num_format': '#.#####'})
    xr=2
    xc=1
    worksheet.write('{}{}'.format('A',xr),'Region')
    worksheet.write('{}{}'.format('B',xr),'Session Name')
    worksheet.write('{}{}'.format('C',xr),'Atol ID')
    worksheet.write('{}{}'.format('D',xr),'Delay (BE)')
    worksheet.write('{}{}'.format('E',xr),'Delay (EF)')
    worksheet.write('{}{}'.format('F',xr),'Packetloss (BE)')
    worksheet.write('{}{}'.format('G',xr),'Packetloss (EF)')
    worksheet.write('{}{}'.format('H',xr),'Jitter (BE)')
    worksheet.write('{}{}'.format('I',xr),'Jitter (EF)')
    worksheet.write('{}{}'.format('J',xr),'BSC-1')

    xr+=1
    for row in rows:

        if not 'EF_PL' in row.keys():
            ef_pl='---'
        else:
            ef_pl=row['EF_PL']
        if not 'EF_DL' in row.keys():
            ef_dl='---'
        else:
            ef_dl=row['EF_DL']
        if not 'EF_JT' in row.keys():
            ef_jt='---'
        else:
            ef_jt=row['EF_JT']
        if not 'BE_PL' in row.keys():
            be_pl='---'
        else:
            be_pl=row['BE_PL']    
        if not 'BE_DL' in row.keys():
            be_dl='---'
        else:
            be_dl=row['BE_DL']
        if not 'BE_JT' in row.keys():
            be_jt='---'
        else:
            be_jt=row['BE_JT']
        #Find BSC"
        bsc_n = '#N/A'
        for bsc in bsc_names:
            atol_id = bsc.split(',')[0].strip()
            if atol_id == row['objectDescription'].strip():
                bsc_n = bsc.split(',')[9].strip()
                break

        row_data=[row['deviceName'],row['objectName'],row['objectDescription'],
                  be_dl,ef_dl,be_pl,ef_pl,be_jt,ef_jt, bsc_n]
        worksheet.write_row('{}{}'.format('A',xr),row_data,number)
        xr+=1
        worksheet.set_column('F:G',15,high_pres)
        worksheet.set_column(1,1,50)
    workbook.close()
    print(reportName)
    print('/home/willcom/{}.xlsx'.format(reportName))
    reportName='Nothando_Report_' + filename_date(time.time())
    workbook = xlsxwriter.Workbook(reportName + ".xlsx")
    worksheet = workbook.add_worksheet()
    number = workbook.add_format({'num_format': '0.00'})
    high_pres = workbook.add_format({'num_format': '#.#####'})
    xr=2
    xc=1
    worksheet.write('{}{}'.format('A',xr),'Region')
    worksheet.write('{}{}'.format('B',xr),'Session Name')
    worksheet.write('{}{}'.format('C',xr),'Atol ID')
    worksheet.write('{}{}'.format('D',xr),'Delay (BE)')
    worksheet.write('{}{}'.format('E',xr),'Delay (EF)')
    worksheet.write('{}{}'.format('F',xr),'Packetloss (BE)')
    worksheet.write('{}{}'.format('G',xr),'Packetloss (EF)')
    worksheet.write('{}{}'.format('H',xr),'Jitter (BE)')
    worksheet.write('{}{}'.format('I',xr),'Jitter (EF)')
    worksheet.write('{}{}'.format('J',xr),'BSC-1')

    xr+=1
    for row in rows:

        if not 'EF_PL' in row.keys():
            ef_pl='---'
        else:
            ef_pl=row['EF_PL']
        if not 'EF_DL' in row.keys():
            ef_dl='---'
        else:
            ef_dl=row['EF_DL']
        if not 'EF_JT' in row.keys():
            ef_jt='---'
        else:
            ef_jt=row['EF_JT']
        if not 'BE_PL' in row.keys():
            be_pl='---'
        else:
            be_pl=row['BE_PL']    
        if not 'BE_DL' in row.keys():
            be_dl='---'
        else:
            be_dl=row['BE_DL']
        if not 'BE_JT' in row.keys():
            be_jt='---'
        else:
            be_jt=row['BE_JT']
        #Find BSC"
        bsc_n = '#N/A'
        for bsc in bsc_names:
            atol_id = bsc.split(',')[0].strip()
            if atol_id == row['objectDescription'].strip():
                bsc_n = bsc.split(',')[9].strip()
                break
        if not (be_pl==100 and ef_pl==100):
            row_data=[row['deviceName'],row['objectName'],row['objectDescription'],
                      be_dl,ef_dl,be_pl,ef_pl,be_jt,ef_jt, bsc_n]
            worksheet.write_row('{}{}'.format('A',xr),row_data,number)
            xr+=1
        worksheet.set_column('F:G',15,high_pres)
        worksheet.set_column(1,1,50)
    workbook.close()
    print(reportName)
    print('/home/willcom/{}.xlsx'.format(reportName))
#send_email('Vodacom Daily report','Hi, \n\n Please find attached the daily report.\n\n Regards \n SevOne', 'SevOne@vodacom.co.za',['rupertk@willcom.co.za'], ['/home/willcom/{}.xlsx'.format(reportName)])

