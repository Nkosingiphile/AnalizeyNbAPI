import requests
import json
import sys


#region = sys.argv[1]
Atholl_filename = sys.argv[1]
Session_filename = sys.argv[2]
AthollInfo=[]
with open(Atholl_filename) as f:
    AthollInfo=f.read().splitlines()

SessionInfo=[]
with open(Session_filename) as f:
    SessionInfo=f.read().splitlines()

# Log into SevOne API.
address = 'http://10.132.98.168/api/v2/'
creds = {'name': 'admin', 'password':'v0dac0m'}
r = requests.post( address + "authentication/signin",
                   data=json.dumps( creds ),
                   headers = { 'content-type': 'application/json' })
response = json.loads( r.text )
#print response 
# Open a session for credential handling.
session = requests.Session()
session.headers.update({ 'content-type': 'application/json',
                         'X-AUTH-TOKEN': response[ 'token' ]})
fixed=[]
for athol_object in AthollInfo:
    athol = athol_object.split(',')
    #print athol
    for a_session_object in SessionInfo:
        a_session = a_session_object.split(',')
        #print a_session
        #print "atholl: %s     list: %s" % (athol[0],a_session[5])
        if athol[0].strip() == a_session[5].strip():
            
            url = 'http://10.132.98.168/api/v2/devices/%s/objects/%s' % (a_session[2],a_session[1])
            print url
            print "%s , %s" % (athol[3].strip(),a_session[3].strip())
            data = '{\n  "description": "%s"\n}' % athol[2].strip()
            print data
            response = session.patch(url, data=data) 
            print response
            fixed.append(athol_object)


missed= list(set(AthollInfo)-set(fixed))

print len(missed)
with open('missed.csv','a') as f:
    for item in missed:
        f.write(item + '\n')
