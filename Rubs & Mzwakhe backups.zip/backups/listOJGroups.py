#!/usr/bin/env python2.7
import requests
import json
import time
import sys
import xlsxwriter

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders
import os
import time
import datetime
import random

def generate_message_id(msg_from):
    domain = msg_from.split("@")[1]
    r = "%s.%s" % (time.time(), random.randint(0, 100))
    mid = "<%s@%s>" % (r, domain)
    return mid

def sendMail(msg_from, to, subject, text,files=[],server="localhost", debug=False):
    assert type(to)==list
    assert type(files)==list

    msg = MIMEMultipart()
    msg['From'] = msg_from
    msg['To'] = COMMASPACE.join(to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    text = text.encode("utf-8")
    text = MIMEText(text, 'plain', "utf-8")
    msg.attach(text)

    msg.add_header('Message-ID', generate_message_id(msg_from))

    for file in files:
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(file,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"'
                       % os.path.basename(file))
        msg.attach(part)

    if not debug:
        smtp = smtplib.SMTP('10.74.25.17')
        smtp.sendmail(msg_from, to, msg.as_string())
        smtp.close()

    return msg

if __name__ == '__main__':

    un = sys.argv[1]
    pwd = sys.argv[2]
    # Log into SevOne API.
    address = 'http://10.132.98.168/api/v2/'
    creds = {'name': un, 'password':pwd}
    r = requests.post( address + "authentication/signin",
                       data=json.dumps( creds ),
                       headers = { 'content-type': 'application/json' })
    response = json.loads( r.text )
    #print response 
    # Open a session for credential handling.
    session = requests.Session()
    session.headers.update({ 'content-type': 'application/json',
                             'X-AUTH-TOKEN': response[ 'token' ]})
 
    # List Object Groups
    r = session.get(address + 'objectgroups?size=500&includeMembers=false')
    objects = json.loads(r.text)
    theList=[]
    for obj in objects['content']:
        if not obj['parentId'] is None:
            theList.append("%s %s" % (obj['id'], obj['name']))

    #print json.dumps(theList)
    for item in theList:
        print "%s" % item.strip()

