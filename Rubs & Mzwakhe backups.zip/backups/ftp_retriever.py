from ftplib import FTP
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

ftp = FTP('10.13.56.190')
ftp.login(user='willcom', passwd = 'w1llc0m')

ftp.cwd('/home/willcom')

def readable_date(timestamp):
    readable_time = datetime.datetime.fromtimestamp(int(timestamp)/1000).strftime('%Y-%m-%d %H:%M:%S')
    return readable_time

def filename_date(timestamp):
    filename_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime('%Y_%m_%d__%H-%M-%S')
    return filename_date

def grabFile(reportName):
    global localfile

    filename = '{}.xlsx'.format(reportName)

    localfile = open(filename, 'wb')
    ftp.retrbinary('RETR ' + filename, localfile.write, 1024)

    ftp.quit()
    localfile.close()

def send_mail():
    fromaddr = "mzwakheb@willcom.co.za"
    toaddr = "giftm@willcom.co.za"
    
    msg = MIMEMultipart()
    
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Daily BE/EF Report"
    
    body = "Please find the spreadsheet attached. Guess what! Email is automated."

    msg.attach(MIMEText(body, 'plain'))
    
    report = localfile
    attachment = open(report, "rb")
    
    part = MIMEBase('application', 'octet-stream')
    part.set_payload((attachment).read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', "attachment; filename= %s" % report)
    
    msg.attach(part)
    
    server = smtplib.SMTP('smtp.office365.com', 587)
    server.starttls()
    server.login(fromaddr, "R3qu3st3r2014")
    text = msg.as_string()
    server.sendmail(fromaddr, toaddr, text)
    server.quit()

reportName='Vodacom_Report_' + filename_date(time.time())
grabFile(reportName)
