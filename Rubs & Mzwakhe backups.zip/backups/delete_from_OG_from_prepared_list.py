import requests
import json
import sys


filename = sys.argv[1]

sites0=[]
with open(filename) as f:
    sites0=f.read().splitlines()
sites = sites0[1:]
url1 = "http://10.132.98.168/api/v1/authentication/signin"
item = '{"name":"%s","password":"%s"}'  % ("Giftm", "v0dac0m")
resp=requests.post(url1,json=json.loads(item))
results=json.loads(resp.content)
token = results['token']

url1 = "http://10.132.98.168/api/v1/devices?size=20"
headers = {"X-AUTH-TOKEN":"%s" % token}
print headers
resp = requests.get(url1,headers=headers)

results=json.loads(resp.content)
devices=[]

#add sites to objectgroup 
for x,object in enumerate(sites):
    #print object
    parts=object.split(',')
    url = "http://10.132.98.168/api/v1/objectgroups/%s/members" % parts[5].strip()
    #print url
    cont = 'a' #raw_input("(a)dd,(s)kip?")
    if cont == 'a':
        item = '{"deviceId":"%s","objectId":"%s"}'  % (parts[2].strip(), parts[0].strip())
        resp=requests.delete(url,headers=headers,json=json.loads(item))
        print item,resp.status_code, resp.text, x 

